import ecs100.*;
import java.awt.Color;
import javax.swing.JColorChooser;

public class FlagWithParameters
{
    //Constants for CORE and COMPLETION  (three stripes flags)
    public static final double FLAG_WIDTH = 200;
    public static final double FLAG_HEIGHT = 133;
    
    public void doVerySimpleFlag(){
        double x = UI.askDouble("X of flag");
        double y = UI.askDouble("Y of flag");
        
        UI.println("Now choose the colours");
        Color stripe1 = JColorChooser.showDialog(null, "First Stripe", Color.white); //JColorChooser.showDialog(null, "First Stripe", Color.white);
        Color stripe2 = JColorChooser.showDialog(null, "Second Stripe", Color.white);  //JColorChooser.showDialog(null, "Second Stripe", Color.white);
        
        this.drawTwoStripesFlag(x,y, stripe1, stripe2 /*# YOUR CODE HERE */ );
    }
    
    public void drawTwoStripesFlag(double x, double y, Color c1, Color c2/*# YOUR CODE HERE */ ){
        UI.clearGraphics();
        /*# YOUR CODE HERE */
        UI.setColor(c1);
        //draw upper rectangle
        double heightStripe = FLAG_HEIGHT/2;
        UI.fillRect(x,y,FLAG_WIDTH, heightStripe);
        
        
        UI.setColor(c2);
        //draw lower rectangle
        UI.fillRect(x,y + heightStripe,FLAG_WIDTH, heightStripe);
        
        //From last week
        UI.setColor(Color.BLACK);
        UI.drawRect(x , y , FLAG_WIDTH, FLAG_HEIGHT);

    }
    
}
